// يُنفَّذ تلقائياً بعد npx cap sync: يضيف إذن الكاميرا ويرفع minSdk
const fs = require('fs');
const mf = 'android/app/src/main/AndroidManifest.xml';
if (fs.existsSync(mf)) {
  let x = fs.readFileSync(mf, 'utf8');
  if (!x.includes('android.permission.CAMERA')) {
    x = x.replace('<application',
      '<uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <application');
    fs.writeFileSync(mf, x);
  }
}
const vg = 'android/variables.gradle';
if (fs.existsSync(vg)) {
  let v = fs.readFileSync(vg, 'utf8');
  v = v.replace(/minSdkVersion\s*=\s*\d+/, 'minSdkVersion = 23');
  fs.writeFileSync(vg, v);
}
