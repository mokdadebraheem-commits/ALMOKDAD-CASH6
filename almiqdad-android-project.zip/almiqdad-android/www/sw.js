'use strict';
/* عند رفع أي تعديل على أي ملف: غيّر رقم CACHE_VERSION ليصل التحديث للمستخدمين. */
const CACHE_VERSION = 'miqdad-v8';
const PRECACHE = [
  './',
  './index.html',
  './manifest.json',
  './css/style.css',
  './js/config.js',
  './js/state.js',
  './js/sec.js',
  './js/boot.js',
  './js/views/home.js',
  './js/views/sell.js',
  './js/views/stock.js',
  './js/views/par.js',
  './js/views/exp.js',
  './js/views/rep.js',
  './js/views/set.js',
  './js/features/trash.js',
  './js/features/backup.js',
  './js/features/audit.js',
  './js/features/ret.js',
  './js/features/adj.js',
  './js/features/scan.js',
  './js/features/share.js',
  './js/features/shift.js',
  './js/features/cat.js',
  './js/features/csvimport.js',
  './icons/icon-72.png',
  './icons/icon-96.png',
  './icons/icon-128.png',
  './icons/icon-144.png',
  './icons/icon-152.png',
  './icons/icon-192.png',
  './icons/icon-384.png',
  './icons/icon-512.png',
  './icons/maskable-192.png',
  './icons/maskable-512.png',
  './icons/apple-touch-icon.png'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_VERSION).then(c => c.addAll(PRECACHE)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_VERSION).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  // لا تتدخل في أي طلب خارجي (الخطوط وغيرها): يذهب للشبكة مباشرة بدون كاش
  if (url.origin !== location.origin) return;
  // لا تتدخل في الطلبات غير GET
  if (e.request.method !== 'GET') return;

  e.respondWith(
    caches.match(e.request).then(cached => {
      if (cached) return cached;
      return fetch(e.request).then(res => {
        if (!res || res.status !== 200 || res.type !== 'basic') return res;
        const clone = res.clone();
        caches.open(CACHE_VERSION).then(c => c.put(e.request, clone));
        return res;
      }).catch(() => e.request.mode === 'navigate' ? caches.match('./index.html') : Response.error());
    })
  );
});
