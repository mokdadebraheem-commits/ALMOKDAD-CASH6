'use strict';
addEventListener('afterprint',()=>{$('#prt').innerHTML=''});
/* تسجيل الأخطاء محلياً في سجل العمليات فقط — لا شبكة (connect-src 'none') */
let _ec=0;
window.onerror=(msg,src,line)=>{try{if(_ec++<30)SEC.log('خطأ',String(msg).slice(0,200)+' @'+String(src||'').split('/').pop()+':'+line)}catch{}return false};
addEventListener('unhandledrejection',e=>{try{if(_ec++<30)SEC.log('خطأ (وعد مرفوض)',String((e.reason&&e.reason.message)||e.reason).slice(0,200))}catch{}});
SEC.boot();

/* تسجيل Service Worker (PWA) */
if('serviceWorker' in navigator&&location.protocol!=='file:'){
  addEventListener('load',()=>{
    navigator.serviceWorker.register('sw.js',{scope:'./'})
      .then(r=>console.log('[PWA] SW registered:',r.scope))
      .catch(e=>console.warn('[PWA] SW failed:',e.message));
  });
}
