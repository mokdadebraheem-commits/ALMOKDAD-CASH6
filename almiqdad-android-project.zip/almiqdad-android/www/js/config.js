'use strict';
const K='miqdad_shop_v1';
const blank=()=>({set:{shop:'محلي',cur:'ل.س',open:0,ns:true,snd:true,catEnabled:true,shiftEnabled:false},shift:{current:null,history:[]},cat:[],prod:[],par:[],sale:[],buy:[],pay:[],exp:[],ret:[],adj:[]});
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const n=x=>typeof x==='string'?(+x.replace(/[٠-٩]/g,c=>c.charCodeAt(0)-1632).replace(/[۰-۹]/g,c=>c.charCodeAt(0)-1776).replace(/٫/g,'.').replace(/[،,\s]/g,'')||0):(+x||0),fmt=x=>n(x).toLocaleString('en-US',{maximumFractionDigits:2}),cur=()=>esc(D.set.cur);
const today=()=>new Date(Date.now()-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,10);
const tm=x=>(x&&x.t)||Date.parse((x&&x.d)||0)||0;
const sm=(L,k)=>L.reduce((a,x)=>a+n(x[k]),0);
const invNo=s=>s.no?'INV-'+String(s.no).padStart(5,'0'):s.id.slice(-5);

/* صوت/اهتزاز التنبيه — الاستدعاء من تفاعل المستخدم يفعّل الصوت في المتصفحات */
let _ac;
function audioPrime(){try{const C=window.AudioContext||window.webkitAudioContext;if(!C)return null;_ac=_ac||new C();if(_ac.state=='suspended')_ac.resume();return _ac}catch{return null}}
function beep(){try{if(D.set.snd===false||document.hidden)return;const a=audioPrime();if(a){const o=a.createOscillator(),g=a.createGain();o.frequency.value=800;g.gain.value=.15;o.connect(g);g.connect(a.destination);o.start();o.stop(a.currentTime+.08)}if(navigator.vibrate)navigator.vibrate([30])}catch{}}
