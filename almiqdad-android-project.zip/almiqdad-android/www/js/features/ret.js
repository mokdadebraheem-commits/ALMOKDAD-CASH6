'use strict';
/* المرتجعات الجزئية — D.ret=[{id,d,t,sid,no,items:[{id,name,qty,price,cost}],total,refund:'cash'|'credit',par,by,reason}] */
const RT={
  L:()=>D.ret||[],
  k:i=>i.id||i.name,
  no:r=>'RTN-'+String(r.no||0).padStart(5,'0'),
  of:sid=>RT.L().filter(r=>r.sid==sid),
  qty:(sid,key)=>RT.of(sid).reduce((a,r)=>a+r.items.reduce((b,i)=>b+(RT.k(i)==key?n(i.qty):0),0),0),
  left:(s,i)=>Math.max(0,n(i.qty)-RT.qty(s.id,RT.k(i))),
  cogs:L=>L.reduce((a,r)=>a+r.items.reduce((b,i)=>b+n(i.qty)*n(i.cost),0),0),
  cash:()=>sm(RT.L().filter(r=>r.refund=='cash'),'total'),
  credit:pid=>sm(RT.L().filter(r=>r.refund=='credit'&&r.par==pid),'total'),
  /* نسبة الخصم على الفاتورة: المرتجع لا يتجاوز ما دفعه الزبون فعلاً */
  ratio:s=>{const sub=s.items.reduce((a,i)=>a+n(i.qty)*n(i.price),0);return sub>0?Math.min(1,n(s.total)/sub):1},
  debt:s=>Math.max(0,n(s.total)-n(s.paid)-sm(RT.of(s.id).filter(r=>r.refund=='credit'),'total')),
  paidLeft:s=>Math.max(0,n(s.paid)-sm(RT.of(s.id).filter(r=>r.refund=='cash'),'total')),
  /* أسطر كشف الزبون: القيمة سالبة؛ النقدي يخصم من القيمة والمدفوع معاً (لا أثر على الدين)، وخصم الدين يقلل الدين */
  /* حدّ الخصم من الدين: لا يتجاوز دين الفاتورة ولا رصيد الزبون الحالي (إن سدّد لاحقاً فلا دين يُخصم منه) */
  creditMax:s=>s.par?Math.max(0,Math.min(RT.debt(s),bal(s.par))):0,
  /* حدّ النقد: ما دُفع على الفاتورة + الجزء الذي سدّده الزبون لاحقاً بدفعات منفصلة */
  cashMax:s=>RT.paidLeft(s)+(s.par?Math.max(0,RT.debt(s)-RT.creditMax(s)):0),
  stmt:pid=>RT.L().filter(r=>(r.par||(D.sale.find(s=>s.id==r.sid)||{}).par)==pid).map(r=>({t:r.t,d:r.d,k:'مرتجع '+RT.no(r)+': '+r.items.map(i=>i.name+' × '+fmt(i.qty)).join('، ')+(r.refund=='cash'?' (نقداً)':' (خصم من الدين)'),a:-n(r.total),b:r.refund=='cash'?-n(r.total):0}))
};

/* تفاصيل الفاتورة + أزرار الإرجاع */
function saleDetail(sid){if(!OWN())return toast('غير مصرح');const s=D.sale.find(x=>x.id==sid);if(!s)return;
document.querySelectorAll('.ov[data-sd]').forEach(e=>e.remove());
const rs=[...RT.of(sid)].sort((a,b)=>tm(a)-tm(b));
const o=ovl(`<h2>فاتورة ${esc(invNo(s))}</h2><p class="mut">${esc(s.d)}${s.par?' — '+esc(pname(s.par)):''}${s.by?' — '+esc(s.by):''}</p>
${s.items.map(i=>{const r=RT.qty(s.id,RT.k(i)),l=RT.left(s,i);return`<div class="rw"><div><b>${esc(i.name)}</b><small class="mut">${fmt(i.qty)} × ${fmt(i.price)} = ${fmt(i.qty*i.price)}${r?` — <span class="warn">مرتجع ${fmt(r)}</span>`:''}</small></div>${l>0?`<button class="btn s" data-i="${esc(RT.k(i))}">إرجاع</button>`:'<small class="mut">أُرجع كاملاً</small>'}</div>`}).join('')}
<div class="tot"><span>الإجمالي</span><b>${fmt(s.total)} ${cur()}</b></div>
<div class="rw"><span class="mut">المدفوع</span><b>${fmt(s.paid)}</b></div>${s.paid<s.total?`<div class="rw"><span class="mut">الباقي (دين)</span><b class="warn">${fmt(RT.debt(s))}</b></div>`:''}
${rs.length?`<h2 style="margin-top:12px">المرتجعات</h2>${rs.map(r=>`<div class="rw"><div><b>${esc(RT.no(r))}</b><small class="mut">${esc(r.d)} — ${r.items.map(i=>esc(i.name)+' × '+fmt(i.qty)).join('، ')} — ${r.refund=='cash'?'نقداً':'خصم من الدين'}${r.reason?' — '+esc(r.reason):''}${r.by?' — '+esc(r.by):''}</small></div><b>${fmt(r.total)} ${cur()}</b></div>`).join('')}`:''}`);
o.dataset.sd='1';
o.addEventListener('click',ev=>{const k=ev.target.dataset&&ev.target.dataset.i;if(k!=null&&ev.target.tagName=='BUTTON')retForm(sid,k)})}

/* نافذة الإرجاع */
function retForm(sid,key){if(!OWN())return toast('غير مصرح');const s=D.sale.find(x=>x.id==sid);if(!s)return;const it=s.items.find(x=>RT.k(x)==key);if(!it)return;
const left=RT.left(s,it);if(left<=0)return toast('أُرجعت كامل الكمية');
const op=[['cash','نقداً']];if(RT.creditMax(s)>0.0001)op.push(['credit','خصم من دين الزبون (المتاح '+fmt(RT.creditMax(s))+')']);
modal('إرجاع: '+esc(it.name)+' — '+esc(invNo(s)),[{k:'q',l:'كمية الإرجاع (المتبقي '+fmt(left)+')',t:'number',v:left},{k:'r',l:'طريقة الإرجاع',o:op},{k:'why',l:'السبب (اختياري)'}],v=>{
/* إعادة قراءة الحالة وقت الحفظ */
const s2=D.sale.find(x=>x.id==sid);if(!s2)return toast('الفاتورة غير موجودة'),false;
const l2=RT.left(s2,it),q=n(v.q);
if(!(q>0&&q<=l2+1e-9))return toast('الكمية يجب أن تكون بين 0 و '+fmt(l2)),false;
const room=Math.max(0,n(s2.total)-sm(RT.of(sid),'total'));
const tot=Math.min(room,Math.round(q*n(it.price)*RT.ratio(s2)*100)/100);
if(v.r=='credit'){if(!s2.par)return toast('الفاتورة بلا زبون'),false;if(tot>RT.creditMax(s2)+0.005)return toast('المبلغ ('+fmt(tot)+') أكبر من الدين المتاح للخصم ('+fmt(RT.creditMax(s2))+') — اختر نقداً'),false}
else if(tot>RT.cashMax(s2)+0.005)return toast('المبلغ ('+fmt(tot)+') أكبر من المدفوع على الفاتورة ('+fmt(RT.cashMax(s2))+') — استخدم خصم الدين'),false;
const p=D.prod.find(x=>x.id==it.id);if(p)p.qty+=q;
D.set.rseq=n(D.set.rseq)+1;const why=String(v.why||'').trim(),cash=v.r!='credit';
(D.ret=D.ret||[]).push({id:uid(),d:today(),t:Date.now(),sid,no:D.set.rseq,shift:SH.id(),items:[{id:it.id,name:it.name,qty:q,price:it.price,cost:it.cost,cat:it.cat}],total:tot,refund:cash?'cash':'credit',par:cash?'':s2.par,by:SEC.name(),reason:why});
SEC.log('مرتجع',invNo(s2)+': '+q+' × '+it.name+' = '+tot+' '+D.set.cur+' ('+(cash?'نقداً':'خصم من الدين')+')'+(why?' — '+why:''));
save();toast('تم الإرجاع');document.querySelectorAll('.ov[data-sd]').forEach(e=>e.remove());draw();saleDetail(sid)})}
