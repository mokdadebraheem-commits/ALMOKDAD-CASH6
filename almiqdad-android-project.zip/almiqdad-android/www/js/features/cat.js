'use strict';
/* أصناف المنتجات — D.cat=[{id,name,color}] و D.prod[].cat = id أو '' */
const CAT={
  on:()=>D.set.catEnabled!==false&&D.cat.length>0,
  name:id=>(D.cat.find(c=>c.id==id)||{}).name||'',
  nid:id=>D.cat.some(c=>c.id==id)?id:'',
  hex:c=>/^#[0-9a-f]{6}$/i.test(c||'')?c:'',
  of:i=>i.cat!==undefined?i.cat:((D.prod.find(p=>p.id==i.id)||{}).cat||'')   /* صنف سطر فاتورة/مرتجع */
};
/* تابات الأصناف: key = اسم متغير الحالة في S (catFilter للمخزون، sellCat للبيع) */
function catChips(key){if(!CAT.on())return'';if(S[key]&&!CAT.nid(S[key]))S[key]='';
  return`<div class="tabs" style="flex-wrap:wrap">${[['','الكل'],...D.cat.map(c=>[c.id,c.name])].map(([id,nm])=>`<button class="${(S[key]||'')==id?'on':''}" data-id="${esc(id)}" onclick="S.${key}=this.dataset.id;V.${key=='catFilter'?'stock':'sell'}()" style="flex:0 0 auto">${esc(nm)}</button>`).join('')}</div>`}
const catOk=(p,key)=>!CAT.on()||!S[key]||p.cat==S[key];

function catSetCard(){const cnt=id=>D.prod.filter(p=>p.cat==id).length;
  return`<div class="card" style="margin-top:12px"><h2>🏷 الأصناف</h2><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" style="width:auto;margin:0" ${D.set.catEnabled!==false?'checked':''} onchange="setOpt('catEnabled',this.checked,'أصناف المنتجات')">تفعيل الأصناف</label>${D.cat.length?D.cat.map(c=>`<div class="rw"><div><b>${CAT.hex(c.color)?`<i style="display:inline-block;width:10px;height:10px;border-radius:50%;margin-inline-end:6px;background:${CAT.hex(c.color)}"></i>`:''}${esc(c.name)}</b><small class="mut">${cnt(c.id)} منتج</small></div><button class="btn s" data-id="${esc(c.id)}" onclick="catForm(this.dataset.id)">تعديل</button><button class="x" data-id="${esc(c.id)}" onclick="catDel(this.dataset.id)" aria-label="حذف">×</button></div>`).join(''):'<p class="mut">لا توجد أصناف بعد.</p>'}<button class="btn s" onclick="catForm()">+ صنف</button></div>`}

function catForm(id){if(!OWN())return toast('غير مصرح');const c=id?D.cat.find(x=>x.id==id):{};if(!c)return;
  modal(id?'تعديل صنف':'صنف جديد',[{k:'name',l:'اسم الصنف',v:c.name},{k:'color',l:'اللون (اختياري)',t:'color',v:CAT.hex(c.color)||'#D4AF37'}],v=>{
    const nm=v.name.trim();if(!nm)return toast('أدخل اسم الصنف'),false;
    if(D.cat.some(x=>x.name==nm&&x.id!=id))return toast('الاسم مستخدم'),false;
    const col=CAT.hex(v.color);
    id?(SEC.log('تعديل صنف',c.name+' → '+nm),Object.assign(c,{name:nm,color:col})):(D.cat.push({id:uid(),name:nm,color:col}),SEC.log('إضافة صنف',nm));
    save();V.set()})}

function catDel(id){if(!OWN())return;const c=D.cat.find(x=>x.id==id);if(!c)return;const k=D.prod.filter(p=>p.cat==id).length;
  if(k)return toast('الصنف مستخدم في '+k+' منتج — انقل المنتجات أولاً');
  if(!confirm('حذف الصنف «'+c.name+'»؟'))return;
  D.cat=D.cat.filter(x=>x.id!=id);if(S.catFilter==id)S.catFilter='';if(S.sellCat==id)S.sellCat='';SEC.log('حذف صنف',c.name);save();V.set()}

/* تقرير: مبيعات حسب الصنف (صافية بعد الخصم والمرتجعات، ضمن فلتر الفترة/الوردية) */
function catCard(){if(!CAT.on())return'';const f=repF(),M={},get=id=>M[id]=M[id]||{c:0,v:0,k:0};
  D.sale.filter(f).forEach(s=>{const r=RT.ratio(s),seen={};s.items.forEach(i=>{const id=CAT.nid(CAT.of(i)),m=get(id);m.v+=n(i.qty)*n(i.price)*r;m.k+=n(i.qty)*n(i.cost);if(!seen[id]){seen[id]=1;m.c++}})});
  RT.L().filter(f).forEach(r=>{const s=D.sale.find(x=>x.id==r.sid),q=s?RT.ratio(s):1;r.items.forEach(i=>{const m=get(CAT.nid(CAT.of(i)));m.v-=n(i.qty)*n(i.price)*q;m.k-=n(i.qty)*n(i.cost)})});
  const R=Object.entries(M).sort((a,b)=>b[1].v-a[1].v),T=R.reduce((a,[,m])=>a+m.v,0);
  return`<div class="card" style="margin-top:14px"><h2>مبيعات حسب الصنف</h2>${R.length?`<table><tr><th>الصنف</th><th>الفواتير</th><th>المبيعات</th><th>الربح</th><th>% من الإجمالي</th></tr>${R.map(([id,m])=>`<tr><td>${esc(CAT.name(id)||'بدون صنف')}</td><td>${m.c}</td><td>${fmt(m.v)}</td><td class="${m.v-m.k<0?'bad':''}">${fmt(m.v-m.k)}</td><td>${T>0?fmt(m.v/T*100):0}%</td></tr>`).join('')}<tr><th>الإجمالي</th><th></th><th>${fmt(T)}</th><th>${fmt(R.reduce((a,[,m])=>a+m.v-m.k,0))}</th><th>${T>0?'100%':''}</th></tr></table>`:'<p class="mut">ما في مبيعات بهالفترة.</p>'}</div>`}
