'use strict';
/* ماسح الباركود بالكاميرا (BarcodeDetector فقط — بلا مكتبات خارجية) */
async function scanUI(){
const cap=window.Capacitor;
if(cap&&cap.isNativePlatform&&cap.isNativePlatform()){
try{
const BS=cap.registerPlugin('BarcodeScanner');
audioPrime();
try{const a=await BS.isGoogleBarcodeScannerModuleAvailable();if(!a.available){toast('جاري تجهيز الماسح لأول مرة… انتظر قليلاً ثم اضغط مسح');await BS.installGoogleBarcodeScannerModule();return}}catch{}
const r=await BS.scan({formats:['EAN_13','EAN_8','CODE_128','QR_CODE']});
const c=String(r&&r.barcodes&&r.barcodes[0]?(r.barcodes[0].rawValue||r.barcodes[0].displayValue||''):'').trim();
if(!c)return;
const p=D.prod.find(x=>String(x.bc||'').trim()==c);
if(p){add(p.id);beep()}else toast('باركود غير مسجل: '+c);
}catch(e){const m=String(e&&e.message||e||'');if(!/cancel/i.test(m))toast('تعذر تشغيل الماسح — تأكد من تحديث خدمات Google Play')}
return}
if(!('BarcodeDetector' in window))return toast('المتصفح لا يدعم المسح — استخدم إدخال الباركود يدوياً');
if(!(navigator.mediaDevices&&navigator.mediaDevices.getUserMedia))return toast('الكاميرا غير متاحة — تحتاج الصفحة إلى HTTPS');
let det;try{const sup=await BarcodeDetector.getSupportedFormats(),fm=['ean_13','ean_8','code_128','qr_code'].filter(f=>sup.includes(f));if(!fm.length)throw 0;det=new BarcodeDetector({formats:fm})}catch{return toast('المتصفح لا يدعم المسح — استخدم إدخال الباركود يدوياً')}
audioPrime();
const o=document.createElement('div');o.className='ov';
o.innerHTML=`<div class="md"><h2>مسح الباركود</h2><video playsinline muted autoplay style="width:100%;border-radius:8px;background:#000;max-height:60vh"></video><p class="mut" id="scm">وجّه الكاميرا نحو الباركود</p><div class="bar"><button class="btn s" data-sw>🔄 تبديل الكاميرا</button><button class="btn s" data-c>إغلاق</button></div></div>`;
document.body.appendChild(o);
const vd=o.querySelector('video');let st=null,face='environment',tm_=0,busy=false,last='',lt=0,dead=false;
const stop=()=>{if(st)st.getTracks().forEach(t=>t.stop());st=null};
const close=()=>{dead=true;clearInterval(tm_);stop();o.remove()};
const start=async()=>{stop();try{st=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:face}},audio:false});if(dead)return stop();vd.srcObject=st;await vd.play().catch(()=>{})}catch{toast('تعذر فتح الكاميرا — تحقق من إذن الكاميرا');close()}};
o.onclick=e=>{if(e.target==o||e.target.dataset.c!=null)close();else if(e.target.dataset.sw!=null){face=face=='environment'?'user':'environment';start()}};
tm_=setInterval(async()=>{if(!o.isConnected)return close();if(busy||!st||vd.readyState<2)return;busy=true;
try{const r=await det.detect(vd);if(r.length){const c=String(r[0].rawValue||'').trim();if(c&&(c!=last||Date.now()-lt>2500)){last=c;lt=Date.now();
const p=D.prod.find(x=>String(x.bc||'').trim()==c);if(p){add(p.id);beep();close();return}toast('باركود غير مسجل')}}}catch{}busy=false},300);
start()}
