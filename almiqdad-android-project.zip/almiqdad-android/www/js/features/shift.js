'use strict';
/* إدارة الورديات — D.shift={current:null|{id,opened,openedBy,openedCash,closed:null},history:[...]}
   تُفعَّل من الإعدادات (D.set.shiftEnabled). كل عملية مالية جديدة تُوسَم shift:<id الوردية الحالية> */
const SH={
  on:()=>!!D.set.shiftEnabled,
  cur:()=>(D.shift&&D.shift.current)||null,
  id:()=>{const c=SH.cur();return c?c.id:''},
  /* البيع مسموح: الورديات معطّلة، أو وردية مفتوحة، أو المالك استخدم «تجاوز» في هذه الجلسة */
  canSell:()=>!SH.on()||!!SH.cur()||(OWN()&&!!S.shOver),
  t:t=>new Date(t).toLocaleString('en-GB').slice(0,17),
  /* حساب النقدية المتوقعة لوردية (بالربط عبر shift id لا بالتاريخ، فلا يتأثر بتاريخ يدوي) */
  calc(id,openedCash){const f=L=>(L||[]).filter(x=>x.shift==id),sl=f(D.sale),py=f(D.pay),
    pt=t=>py.filter(y=>(D.par.find(p=>p.id==y.par)||{}).type==t);
    const cashSales=sm(sl,'paid'),salesTotal=sm(sl,'total'),cashIn=sm(pt('c'),'amt'),paySup=sm(pt('s'),'amt'),
      buyPaid=sm(f(D.buy),'paid'),exp=sm(f(D.exp),'amt'),cashRet=sm(f(D.ret).filter(r=>r.refund=='cash'),'total');
    return{salesCount:sl.length,salesTotal,cashSales,creditSales:salesTotal-cashSales,cashIn,paySup,buyPaid,exp,cashRet,
      cashOut:paySup+buyPaid+exp+cashRet,
      expected:n(openedCash)+cashSales+cashIn-paySup-buyPaid-exp-cashRet}},
  /* شريط الوردية (أعلى الرئيسية والبيع) */
  bar(sellTab){if(!SH.on())return'';const c=SH.cur();
    if(!c)return`<div class="card rw" id="shb" style="margin-bottom:12px;border-top-color:var(--ok)"><div class="ok">🟢 لا توجد وردية مفتوحة — افتح وردية لبدء العمل${OWN()&&S.shOver?'<small class="warn">⚠ تجاوز الوردية مفعّل في هذه الجلسة — البيع لا يُسجَّل ضمن وردية</small>':''}</div><button class="btn" onclick="shOpen()">فتح وردية</button>${sellTab&&OWN()&&!S.shOver?'<button class="btn s" onclick="shOver()">تجاوز</button>':''}</div>`;
    const e=SH.calc(c.id,c.openedCash).expected;
    return`<div class="card rw" id="shb" style="margin-bottom:12px;position:sticky;top:0;z-index:5;border-top-color:var(--ok)"><div>🟢 الوردية مفتوحة — بدأت ${esc(SH.t(c.opened))} | النقدية المتوقعة: <b class="ok">${fmt(e)} ${cur()}</b></div><button class="btn s" onclick="shClose()">إغلاق الوردية</button></div>`},
  /* فلتر التقارير */
  select(){const h=D.shift.history,c=SH.cur();if(!SH.on()&&!h.length&&!c)return'';
    const L=[...(c?[[c.id,'الوردية الحالية — '+SH.t(c.opened)]]:[]),...[...h].reverse().slice(0,20).map(r=>[r.id,SH.t(r.opened)+' ← '+SH.t(r.closed)+' ('+r.closedBy+')'])];
    if(S.shf&&!L.some(x=>x[0]==S.shf))S.shf='';
    return`<label>الوردية<select onchange="S.shf=this.value;V.rep()"><option value="">كل الورديات</option>${L.map(([id,l])=>`<option value="${esc(id)}" ${S.shf==id?'selected':''}>${esc(l)}</option>`).join('')}</select></label>`},
  label(){const id=S.shf;if(!id)return'';const r=D.shift.history.find(x=>x.id==id),c=SH.cur();return r?SH.t(r.opened):(c&&c.id==id?'الوردية الحالية':'')}
};

const shLabel=id=>{const r=D.shift.history.find(x=>x.id==id);return r?SH.t(r.opened):(SH.id()==id?SH.t(SH.cur().opened):'')};
function shOpen(){if(SH.cur())return toast('توجد وردية مفتوحة');const h=D.shift.history,last=h[h.length-1];
  modal('فتح وردية',[{k:'c',l:'الرصيد الافتتاحي'+(last?' (افتراضياً: النقدية الفعلية للوردية السابقة)':''),t:'number',v:last?last.actualCash:n(D.set.open)}],v=>{
    if(SH.cur())return toast('توجد وردية مفتوحة'),false;
    if(String(v.c).trim()==='')return toast('أدخل الرصيد الافتتاحي'),false;
    D.shift.current={id:uid(),opened:Date.now(),openedBy:SEC.name(),openedCash:n(v.c),closed:null};S.shOver=false;
    SEC.log('فتح وردية','رصيد افتتاحي '+n(v.c));save();draw()})}

function shOver(){if(!OWN())return;if(!confirm('تحذير: ستبيع بدون وردية مفتوحة، ولن تُحتسب العمليات ضمن أي وردية. متابعة؟'))return;
  S.shOver=true;SEC.log('تجاوز الوردية','بيع بدون وردية مفتوحة');draw()}

function shClose(){const c=SH.cur();if(!c)return;const b=SH.calc(c.id,c.openedCash);
  const R=(a,v,s)=>`<tr><td>${a}</td><td>${s}${fmt(v)} ${cur()}</td></tr>`;
  const o=document.createElement('div');o.className='ov';
  o.innerHTML=`<div class="md wide"><h2>إغلاق الوردية</h2><p class="mut">بدأت ${esc(SH.t(c.opened))} — ${esc(c.openedBy)}</p><table>${R('رصيد الافتتاح',c.openedCash,'')}${R('مبيعات نقدية ('+b.salesCount+' فاتورة)',b.cashSales,'+ ')}${R('قبض من الزبائن',b.cashIn,'+ ')}${R('دفع للموردين',b.paySup,'− ')}${R('مشتريات مدفوعة',b.buyPaid,'− ')}${R('مصاريف',b.exp,'− ')}${R('مرتجعات نقدية',b.cashRet,'− ')}<tr><th>النقدية المتوقعة</th><th>${fmt(b.expected)} ${cur()}</th></tr></table><label>النقدية الفعلية في الصندوق<input id="shA" type="number" step="any" min="0" inputmode="decimal"></label><label>ملاحظات (اختياري)<input id="shN"></label><div class="bar"><button class="btn" data-go>إنهاء الوردية</button><button class="btn s" data-c>إلغاء</button></div></div>`;
  document.body.appendChild(o);o.querySelector('#shA').focus();
  o.onclick=e=>{if(e.target==o||e.target.dataset.c!=null)return o.remove();if(e.target.dataset.go==null)return;
    const c2=SH.cur();if(!c2||c2.id!=c.id)return o.remove();
    const av=o.querySelector('#shA').value;if(String(av).trim()==='')return toast('أدخل النقدية الفعلية');
    const act=n(av),b2=SH.calc(c2.id,c2.openedCash),diff=Math.round((act-b2.expected)*100)/100,notes=o.querySelector('#shN').value.trim(),at=Date.now();
    c2.closed={closedAt:at,closedBy:SEC.name(),actualCash:act,expectedCash:b2.expected,diff,notes};
    D.shift.history.push({id:c2.id,opened:c2.opened,closed:at,openedBy:c2.openedBy,closedBy:SEC.name(),openedCash:c2.openedCash,actualCash:act,expectedCash:b2.expected,diff,
      salesCount:b2.salesCount,salesTotal:b2.salesTotal,cashSales:b2.cashSales,creditSales:b2.creditSales,cashIn:b2.cashIn,cashOut:b2.cashOut,notes});
    D.shift.current=null;
    SEC.log('إغلاق وردية','متوقع '+b2.expected+'، فعلي '+act+'، الفرق '+diff+(notes?' — '+notes:''));save();o.remove();draw();
    const cls=diff<-0.005?'bad':diff>0.005?'warn':'ok',msg=diff<-0.005?'⚠ عجز في الصندوق: '+fmt(diff):diff>0.005?'⚠ زيادة في الصندوق: +'+fmt(diff):'✓ الصندوق مطابق';
    const r=ovl(`<h2>تم إغلاق الوردية</h2><div class="card ${cls}"><b>${msg} ${cur()}</b><br><small>المتوقع ${fmt(b2.expected)} — الفعلي ${fmt(act)}</small></div><div class="bar" style="margin-top:10px"><button class="btn s" data-p>🖨 طباعة الكشف</button></div>`);
    r.addEventListener('click',e=>{if(e.target.dataset.p!=null)printShift(c2.id)})}}

function printShift(id){const r=D.shift.history.find(x=>x.id==id);if(!r)return;const m=v=>fmt(v)+' '+cur(),R=(a,b)=>`<tr><td>${a}</td><td>${b}</td></tr>`;
  $('#prt').innerHTML=`<h2>${esc(D.set.shop)}</h2><div class="t"><span>كشف وردية</span><span>${esc(SH.t(r.closed))}</span></div><div>فتح: ${esc(SH.t(r.opened))} — ${esc(r.openedBy)}</div><div>إغلاق: ${esc(SH.t(r.closed))} — ${esc(r.closedBy)}</div><table>${R('الرصيد الافتتاحي',m(r.openedCash))}${R('عدد الفواتير',fmt(r.salesCount))}${R('إجمالي المبيعات',m(r.salesTotal))}${R('مبيعات نقدية',m(r.cashSales))}${R('مبيعات آجلة',m(r.creditSales))}${R('قبض من الزبائن',m(r.cashIn))}${R('مدفوعات (موردون/شراء/مصاريف/مرتجعات)',m(r.cashOut))}${R('النقدية المتوقعة',m(r.expectedCash))}${R('النقدية الفعلية',m(r.actualCash))}${R(r.diff<0?'العجز':'الزيادة',m(r.diff))}</table>${r.notes?`<p>ملاحظات: ${esc(r.notes)}</p>`:''}`;
  SEC.log('طباعة كشف وردية',SH.t(r.opened));applyPW();requestAnimationFrame(()=>requestAnimationFrame(()=>setTimeout(()=>window.print(),30)))}

function shToggle(on){if(!OWN())return;if(!on&&SH.cur()){toast('أغلق الوردية المفتوحة أولاً');return V.set()}
  setOpt('shiftEnabled',!!on,'الورديات');S.shOver=false;V.set()}

/* بطاقة الإعدادات: تفعيل + آخر 20 وردية */
function shSetCard(){const H=[...D.shift.history].reverse().slice(0,20),c=SH.cur();
  return`<div class="card" style="margin-top:12px"><h2>🕒 الورديات</h2><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" style="width:auto;margin:0" ${SH.on()?'checked':''} onchange="shToggle(this.checked)">تفعيل إدارة الورديات (فتح/إغلاق الصندوق)</label>${c?`<p class="ok">🟢 وردية مفتوحة منذ ${esc(SH.t(c.opened))} — ${esc(c.openedBy)}</p>`:''}${H.length?H.map(r=>`<div class="rw"><div><b>${esc(SH.t(r.closed))}</b><small class="mut">${esc(r.closedBy)} — مبيعات ${fmt(r.salesTotal)} (${r.salesCount})</small></div><b class="${r.diff<-0.005?'bad':r.diff>0.005?'warn':'ok'}">${fmt(r.diff)}</b><button class="btn s" data-id="${esc(r.id)}" onclick="printShift(this.dataset.id)">طباعة كشف</button></div>`).join(''):'<p class="mut">لا توجد ورديات سابقة.</p>'}</div>`}
