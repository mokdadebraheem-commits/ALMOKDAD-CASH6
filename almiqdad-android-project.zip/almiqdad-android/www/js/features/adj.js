'use strict';
/* تسويات المخزون — D.adj=[{id,d,t,prod,name,qty,kind,cost,note,by}] */
const AJ={
  L:()=>D.adj||[],
  K:{damage:'تالف',loss:'فاقد',gift:'هدية',count:'جرد',correction:'تصحيح'},
  /* خسائر التالف/الفاقد بسعر التكلفة ضمن فترة */
  loss:f=>AJ.L().filter(a=>f(a)&&n(a.qty)<0&&(a.kind=='damage'||a.kind=='loss')).reduce((s,a)=>s+Math.abs(n(a.qty))*n(a.cost),0)
};
function adjForm(id){if(!OWN())return toast('غير مصرح');const p=D.prod.find(x=>x.id==id);if(!p)return;
const o=document.createElement('div');o.className='ov';
o.innerHTML=`<form class="md"><h2>تسوية: ${esc(p.name)}</h2><p class="mut">الكمية الحالية: <b>${fmt(p.qty)}</b></p>
<div class="bar">${Object.entries(AJ.K).map(([k,l],i)=>`<label style="margin:0;display:flex;gap:4px;align-items:center;color:inherit"><input type="radio" name="kind" value="${k}" ${i?'':'checked'} style="width:auto;margin:0">${l}</label>`).join('')}</div>
<label><span id="aql"></span><input name="q" type="number" step="any" inputmode="decimal"></label><p id="adf" class="mut"></p>
<label>ملاحظة (اختياري)<input name="note"></label>
<div class="bar"><button class="btn">حفظ</button><button type="button" class="btn s" data-c>إلغاء</button></div></form>`;
document.body.appendChild(o);const fm=o.firstChild,close=()=>o.remove();
const delta=(k,q)=>k=='count'?q-n(p.qty):k=='correction'?q:-Math.abs(q);
const LB={damage:'الكمية التالفة (تُخصم من المخزون)',loss:'الكمية الفاقدة (تُخصم من المخزون)',gift:'الكمية المُهداة (تُخصم من المخزون)',correction:'الفرق (موجب = زيادة، سالب = نقص)',count:'الكمية الفعلية بعد الجرد'};
const upd=()=>{const k=fm.kind.value;$('#aql').textContent=LB[k];const raw=fm.q.value,pv=$('#adf');if(raw===''){pv.textContent='';return}const d=delta(k,n(raw));pv.textContent='الفرق: '+(d>0?'+':'')+fmt(d)+' ← المخزون يصبح '+fmt(n(p.qty)+d)};
fm.addEventListener('input',upd);upd();
o.onclick=e=>{if(e.target==o||e.target.dataset.c!=null)close()};
fm.onsubmit=e=>{e.preventDefault();const k=fm.kind.value,raw=fm.q.value;
if(raw==='')return toast('أدخل الكمية');
const d=delta(k,n(raw)),old=n(p.qty);if(!d)return toast(k=='count'?'الجرد مطابق للمخزون — لا فرق':'الكمية صفر');
if(k!='count'&&old+d<0)return toast('النقص ('+fmt(-d)+') أكبر من المخزون ('+fmt(old)+') — استخدم «جرد» لتصحيح الرصيد');
const nq=Math.round((old+d)*1e6)/1e6,note=fm.note.value.trim();
p.qty=nq;(D.adj=D.adj||[]).push({id:uid(),d:today(),t:Date.now(),shift:SH.id(),prod:p.id,name:p.name,qty:d,kind:k,cost:n(p.cost),note,by:SEC.name()});
SEC.log('تسوية مخزون',p.name+' | '+AJ.K[k]+': '+(d>0?'+':'')+d+' (من '+old+' إلى '+nq+')'+(note?' — '+note:''));
save();close();toast('تم حفظ التسوية');V.stock()};
fm.q.focus()}
/* سجل تسويات منتج */
function adjLog(id){if(!OWN())return;const p=D.prod.find(x=>x.id==id),L=AJ.L().filter(a=>a.prod==id).sort((a,b)=>tm(b)-tm(a));
ovl(`<h2>سجل التسويات${p?': '+esc(p.name):''}</h2>${L.length?L.map(a=>`<div class="rw"><div><b>${esc(AJ.K[a.kind]||a.kind)}</b><small class="mut">${esc(a.d)} — ${esc(a.by||'')}${a.note?' — '+esc(a.note):''}</small></div><b class="${n(a.qty)<0?'bad':'ok'}">${n(a.qty)>0?'+':''}${fmt(a.qty)}</b></div>`).join(''):'<p class="mut">لا توجد تسويات.</p>'}`)}
