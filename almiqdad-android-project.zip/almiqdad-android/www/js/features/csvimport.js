'use strict';
/* استيراد المنتجات من CSV (Excel) — بلا مكتبات. الأعمدة: name,bc,cost,price,qty,min,cat */
const CSVI_MAX=2*1024*1024,CSVI_ROWS=5000;
const CSVI_COLS={name:['name','الاسم','اسم المنتج','المنتج'],bc:['bc','barcode','الباركود'],cost:['cost','سعر الشراء','التكلفة','الشراء'],price:['price','سعر البيع','السعر','البيع'],qty:['qty','quantity','الكمية'],min:['min','حد التنبيه','الحد الأدنى'],cat:['cat','category','الصنف','التصنيف']};
function parseCSV(t){t=t.replace(/^\uFEFF/,'');const l1=t.split(/\r?\n/)[0]||'',dl=[',',';','\t'].map(c=>[c,l1.split(c).length-1]).sort((a,b)=>b[1]-a[1])[0][0];
  const rows=[];let r=[],f='',q=false;
  for(let i=0;i<t.length;i++){const c=t[i];
    if(q){if(c=='"'){if(t[i+1]=='"'){f+='"';i++}else q=false}else f+=c}
    else if(c=='"'&&!f)q=true;
    else if(c==dl){r.push(f);f=''}
    else if(c=='\n'||c=='\r'){if(c=='\r'&&t[i+1]=='\n')i++;r.push(f);f='';if(r.some(x=>x.trim()!==''))rows.push(r);r=[]}
    else f+=c}
  r.push(f);if(r.some(x=>x.trim()!==''))rows.push(r);return rows}
/* يحوّل الصفوف إلى سجلات منتجات مع حالة كل صف */
function csvPlan(rows){if(!rows.length)return{L:[],newCats:[]};
  const norm=s=>String(s).trim().toLowerCase(),hdr=rows[0].map(norm),isH=hdr.some(h=>CSVI_COLS.name.includes(h));
  const idx={};if(isH){for(const k in CSVI_COLS){const i=hdr.findIndex(h=>CSVI_COLS[k].includes(h));if(i>=0)idx[k]=i}}else['name','bc','cost','price','qty','min','cat'].forEach((k,i)=>idx[k]=i);
  if(idx.name===undefined)return{L:[],newCats:[],err:'لا يوجد عمود name (الاسم)'};
  const get=(r,k)=>idx[k]===undefined?'':String(r[idx[k]]??'').replace(/[\u0000-\u001f]/g,' ').trim();
  const bcs=new Set(D.prod.map(p=>String(p.bc||'').trim()).filter(Boolean)),nms=new Set(D.prod.map(p=>norm(p.name))),newCats=[];
  const L=(isH?rows.slice(1):rows).slice(0,CSVI_ROWS).map(r=>{const name=get(r,'name').slice(0,100),bc=get(r,'bc').slice(0,40),cname=get(r,'cat').slice(0,60);
    const o={name,bc,cost:n(get(r,'cost')),price:n(get(r,'price')),qty:n(get(r,'qty')),min:n(get(r,'min')),cname,st:'ok',why:''};
    if(!name)o.st='err',o.why='بلا اسم';
    else if(o.cost<0||o.price<0||o.qty<0||o.min<0)o.st='err',o.why='قيمة سالبة';
    else if(bc&&bcs.has(bc))o.st='dup',o.why='باركود مكرر';
    else if(nms.has(norm(name)))o.st='dup',o.why='اسم مكرر';
    if(o.st=='ok'){if(bc)bcs.add(bc);nms.add(norm(name));if(cname&&!D.cat.some(c=>c.name==cname)&&!newCats.includes(cname))newCats.push(cname)}
    return o});
  return{L,newCats}}
async function csvImport(f){if(!OWN())return toast('غير مصرح');if(!f)return;
  if(f.size>CSVI_MAX)return toast('الملف كبير (الحد 2MB)');
  let buf;try{buf=await f.arrayBuffer()}catch{return toast('تعذر قراءة الملف')}
  let txt;try{txt=new TextDecoder('utf-8',{fatal:true}).decode(buf)}catch{try{txt=new TextDecoder('windows-1256').decode(buf)}catch{return toast('ترميز الملف غير مدعوم')}}
  const P=csvPlan(parseCSV(txt));if(P.err)return toast(P.err);if(!P.L.length)return toast('الملف فارغ');
  const ok=P.L.filter(x=>x.st=='ok'),dup=P.L.filter(x=>x.st=='dup').length,er=P.L.filter(x=>x.st=='err').length;
  const o=ovl(`<h2>معاينة الاستيراد</h2><p class="mut">${P.L.length} صف — جديد: <b class="ok">${ok.length}</b> • مكرر (سيُتخطى): <b class="warn">${dup}</b> • أخطاء (سيُتخطى): <b class="bad">${er}</b>${P.newCats.length&&D.set.catEnabled!==false?`<br>أصناف جديدة ستُنشأ: ${esc(P.newCats.join('، '))}`:''}</p><div style="overflow:auto;max-height:45vh"><table><tr><th>الاسم</th><th>باركود</th><th>شراء</th><th>بيع</th><th>الكمية</th><th>الصنف</th><th>الحالة</th></tr>${P.L.slice(0,50).map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.bc)}</td><td>${fmt(x.cost)}</td><td>${fmt(x.price)}</td><td>${fmt(x.qty)}</td><td>${esc(x.cname)}</td><td class="${x.st=='ok'?'ok':x.st=='dup'?'warn':'bad'}">${x.st=='ok'?'جديد':esc(x.why)}</td></tr>`).join('')}</table></div>${P.L.length>50?`<p class="mut">تُعرض أول 50 صفاً فقط من ${P.L.length}.</p>`:''}<div class="bar" style="margin-top:10px"><button class="btn" data-go ${ok.length?'':'disabled'}>استيراد ${ok.length} منتج</button></div>`);
  o.addEventListener('click',e=>{if(e.target.dataset.go==null)return;if(!OWN())return;
    const ids={};if(D.set.catEnabled!==false)P.newCats.forEach(nm=>{if(!D.cat.some(c=>c.name==nm)){const c={id:uid(),name:nm,color:''};D.cat.push(c)}});
    let k=0;ok.forEach(x=>{if(x.bc&&D.prod.some(p=>String(p.bc||'').trim()==x.bc))return;const c=D.set.catEnabled!==false&&x.cname?D.cat.find(c=>c.name==x.cname):null;
      D.prod.push({id:uid(),name:x.name,bc:x.bc,cost:x.cost,price:x.price,qty:x.qty,min:x.min,cat:c?c.id:''});k++});
    SEC.log('استيراد منتجات','استيراد '+k+' منتج من CSV (تخطي '+(dup+er)+')');save();o.remove();toast('تم استيراد '+k+' منتج');V.stock()})}
