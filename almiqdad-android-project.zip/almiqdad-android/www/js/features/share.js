'use strict';
/* مشاركة الفاتورة عبر واتساب */
function waText(s){const sub=s.items.reduce((a,i)=>a+n(i.qty)*n(i.price),0),ds=sub-n(s.total),rt=sm(RT.of(s.id),'total'),debt=RT.debt(s);
return [D.set.shop,'فاتورة '+invNo(s),'التاريخ: '+s.d,'',...s.items.map(i=>i.name+' × '+fmt(i.qty)+' = '+fmt(i.qty*i.price)),'',
...(ds>0.0001?['الخصم: '+fmt(ds)]:[]),'الإجمالي: '+fmt(s.total)+' '+D.set.cur,...(rt>0?['المرتجعات: '+fmt(rt)+' '+D.set.cur]:[]),...(debt>0.0001?['الباقي: '+fmt(debt)+' '+D.set.cur]:[])].join('\n')}
function waForm(id){const s=D.sale.find(x=>x.id==id);if(!s)return;const pr=D.par.find(p=>p.id==s.par)||{};
modal('إرسال الفاتورة عبر واتساب',[{k:'ph',l:'رقم الزبون (فارغ = اختيار جهة الاتصال من واتساب)',t:'tel',v:pr.ph||''},{k:'cc',l:'رمز الدولة للأرقام المحلية (مثال 963)',v:D.set.cc||''}],v=>{
let num=String(v.ph||'').replace(/[٠-٩]/g,c=>c.charCodeAt(0)-1632).replace(/[۰-۹]/g,c=>c.charCodeAt(0)-1776).replace(/\D/g,''),cc=String(v.cc||'').replace(/\D/g,'');
if(num.startsWith('00'))num=num.slice(2);else if(num.startsWith('0')){if(!cc)return toast('أدخل رمز الدولة أو اكتب الرقم بصيغة دولية'),false;num=cc+num.slice(1)}
if(num&&num.length<8)return toast('الرقم غير صحيح'),false;
if(cc!==String(D.set.cc||'')){D.set.cc=cc;save()}
SEC.log('مشاركة فاتورة',invNo(s)+' عبر واتساب');
window.open('https://wa.me/'+num+'?text='+encodeURIComponent(waText(s)),'_blank','noopener')})}
