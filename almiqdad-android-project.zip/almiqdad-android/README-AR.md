# تحويل المقداد كاش إلى APK

## الطريقة 1: بدون Android Studio (عبر GitHub)
1. أنشئ مستودع جديد على github.com وارفع كل محتويات هذا المجلد (بما فيها .github).
2. من تبويب Actions اختر "Build APK" ثم Run workflow.
3. بعد ~5 دقائق نزّل ملف almiqdad-cash-apk من Artifacts وثبّته على الجوال.

## الطريقة 2: على جهازك (Node 18+ و Android Studio)
npm install
npx cap add android
npx cap sync android
npx cap open android   # ثم Build > Build APK

## ملاحظات
- البيانات تُحفظ محلياً داخل التطبيق (مثل النسخة الحالية)، فخذ نسخة احتياطية من التطبيق القديم قبل الانتقال، لأن تخزين المتصفح لا ينتقل للتطبيق.
- لنشر التطبيق على Google Play تحتاج توقيع Release (keystore) وبناء AAB.
